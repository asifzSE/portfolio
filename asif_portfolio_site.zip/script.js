document.getElementById("theme-toggle").addEventListener("click", function () {
  document.body.classList.toggle("light-mode");
});